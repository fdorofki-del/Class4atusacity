#!/usr/bin/env python3
import re, subprocess, sys, tempfile, pathlib

if len(sys.argv) != 2:
    print('Usage: check_js.py <html>')
    sys.exit(2)

html = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
scripts = re.findall(r'<script(?:\\s[^>]*)?>(.*?)</script>', html, flags=re.I | re.S)
if not scripts:
    print('No inline JavaScript found; check skipped.')
    sys.exit(0)

with tempfile.TemporaryDirectory() as td:
    failed = False
    for i, code in enumerate(scripts, 1):
        if not code.strip():
            continue
        p = pathlib.Path(td) / f'script_{i}.js'
        p.write_text(code, encoding='utf-8')
        result = subprocess.run(['node', '--check', str(p)], text=True, capture_output=True)
        if result.returncode != 0:
            failed = True
            print(f'JavaScript syntax error in script block {i}:')
            print(result.stderr)
    if failed:
        sys.exit(1)

print(f'JavaScript syntax check passed ({len(scripts)} script block(s)).')
