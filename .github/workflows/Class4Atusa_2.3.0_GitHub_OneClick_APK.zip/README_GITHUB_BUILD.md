# Class4Atusa 2.3.0 — GitHub APK Build

این نسخه برای ساخت APK با GitHub Actions آماده شده است.

## ساخت APK با یک دکمه

1. یک Repository جدید در GitHub بسازید.
2. تمام فایل‌های این پروژه را داخل Repository قرار دهید.
3. به تب **Actions** بروید.
4. Workflow با نام **Build Class4Atusa APK** را انتخاب کنید.
5. روی **Run workflow** بزنید.
6. پس از پایان Build، وارد اجرای موفق Workflow شوید.
7. در پایین صفحه، بخش **Artifacts** را باز کنید.
8. فایل `Class4Atusa-APK-2.3.0` را دانلود کنید.
9. داخل آن دو APK وجود دارد:
   - `Class4Atusa-2.3.0-debug.apk` — نصب‌شدنی و امضاشده برای تست
   - `Class4Atusa-2.3.0-release-unsigned.apk` — نسخه Release بدون امضای انتشار

## نکته مهم درباره امضای نهایی

APK دیباگ برای نصب و تست روی گوشی آماده است. برای انتشار رسمی یا به‌روزرسانی‌های آینده، Release باید با یک Keystore شخصی که فقط خود صاحب برنامه نگهداری می‌کند امضا شود. Keystore را داخل GitHub Repository قرار ندهید.

## ویژگی Workflow

- Java 17
- Android SDK 35
- Build Tools 35.0.0
- Gradle 8.11.1
- بررسی Syntax جاوااسکریپت قبل از Build
- ساخت Debug APK
- ساخت Release APK
- تحویل APKها به‌عنوان GitHub Artifact
